from lib.utils.utils import Recon
from render import Render
import time

import torch.nn.functional as F

def RenderLoss(ceof, mask, normal_gt):

    recon = Recon(device=ceof.device)
    R = Render(device=ceof.device) #手动指定GUP

    loss = 0

    batch_size = mask.shape[0]

    for i in range (batch_size):

        mesh_input = ceof[i] * mask[i]
        #mesh_input = mesh_input.to(device=torch.device("cuda:6"))

        #mesh_input = mesh_input.to(device=ceof.device)
        #start_time = time.time()
        v, f = recon.decode(mesh_input)  #开始mesh 不标准，需要专用很长时间. 刚开始不适合用这个损失函数
        # 记录结束时间
        #end_time = time.time()
        #print("v f ", end_time - start_time)

        #start_time = time.time()
        normal_render = R.get_rgb_image(verts=v, faces=f)  # (-1,1)
        #end_time = time.time()
        #print("render ", end_time - start_time)

        #device2 = torch.device("cuda:6")
        normal_render = normal_render.to(device = ceof.device)

        loss_normal = F.l1_loss(normal_render, normal_gt[i:i+1])
        loss = loss + loss_normal

    return loss/batch_size