import torch
import torch.nn as nn
import torch.nn.functional as F
from .ceof_generator import tri_occ
from .provider_lmdb import LmdbDataProvider


class FOFDataset(torch.utils.data.Dataset):
    # def __init__(self, name_list = "/mnt/fq_ssd/fq/FOF/namelist/train.txt") -> None:
    def __init__(self, name_list="/mnt/data1/LYZ_160/data/data/train.txt") -> None:  # -> None 返回值类型  可有可无
        super().__init__()
        self.data_provider = LmdbDataProvider()
        self.train_mode = True
        with open(name_list, "r") as f:
            self.name_list = f.read().split()

    def open_db(self):
        self.data_provider.open_db()

    def __len__(self):
        if self.train_mode:
            return len(self.name_list) * 256
        else:
            return len(self.name_list)

    def __getitem__(self, index):
        if self.train_mode:
            pid = index // 256
            vid = index % 256
        else:
            pid = index
            vid = int(torch.randint(256, (1,)))
        name = self.name_list[pid]


        data1 = self.data_provider.get_data_base(name, vid)
        imgF = torch.from_numpy(data1["imgF"].transpose((2, 0, 1)))
        imgB = torch.from_numpy(data1["imgB"].transpose((2, 0, 1)))
        ceof, mask = tri_occ(data1["mpi"]["pos"], data1["mpi"]["ind"], data1["mpi"]["val"], 16)
        ceof = torch.from_numpy(ceof.transpose((2, 0, 1)))
        mask = torch.from_numpy(mask[None])

        return {
            "name": "%s_%03d" % (name, vid),
            "imgF": imgF,
            "imgB": imgB,
            "ceof": ceof,
            "mask": mask
        }


def random_init(id):
    torch.utils.data.get_worker_info().dataset.open_db()


def fixed_init(id):
    torch.manual_seed(1000000000 + 7 + id)
    torch.utils.data.get_worker_info().dataset.open_db()


def get_dataloader(fixed=False, batch_size=2):
    return torch.utils.data.DataLoader(FOFDataset(), batch_size=batch_size,
                                       num_workers=8,  # 12
                                       shuffle=not fixed, worker_init_fn=fixed_init if fixed else random_init,
                                       pin_memory=False, persistent_workers=True)
