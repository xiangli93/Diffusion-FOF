import os
import cv2
import torch
import torch.nn.functional as F
from torch.nn.parallel import DataParallel
import numpy as np
import argparse
import time

from lib.dataset.train_dataset_fof import get_dataloader
from lib.network.HRNet import HRNetV2_W32 as network
from lib.utils.utils import toDevice
from torch import optim
from Diffusion import GaussianDiffusionTrainer
#from model import Model
from unet.modules import UNet






def train(args):
    torch.backends.cudnn.benchmark = True

    device = torch.device("cuda:%d" % args.gpu_id)
    #device = torch.device("cuda:0")
    torch.cuda.set_device(device)
    print("using device:", device)

    DL = get_dataloader(fixed=False, batch_size=args.batch_size)
    print("training dataset size:", len(DL))

    start_epoch = 0

    # model setup
    net_model = UNet().to(device)
    #net_model = DataParallel(net_model, device_ids=[0,1])

    optimizer = torch.optim.Adam(net_model.parameters(), lr=0.0001)
    #optimizer = torch.optim.AdamW(net_model.parameters(), lr=args.lr, weight_decay=1e-4)
    trainer = GaussianDiffusionTrainer(
        net_model, args.beta_1, args.beta_T, args.T).to(device)

    # continue to train
    os.makedirs("ckpt/%s" % args.name, exist_ok=True)
    if args.continue_train:
        ckpt_list = sorted(os.listdir(os.path.join("ckpt", args.name)))
        if len(ckpt_list) > 0:
            ckpt_path = os.path.join("ckpt", args.name, ckpt_list[-1])
            print('Resuming from ', ckpt_path)
            state_dict = torch.load(ckpt_path)
            start_epoch = state_dict["epoch"]
            net_model.load_state_dict(state_dict["net"])
            optimizer.load_state_dict(state_dict["optimizer"])
            del state_dict

    # start train

    for epoch in range(start_epoch, args.num_epoch, 1):
        num_iteration = 0
        net_model.train()
        for data in DL:
            data = toDevice(data, device)

            img = (data["imgF"] / 127.5 - 1) * data["mask"]
            ceof_gt = data["ceof"] * data["mask"]

            loss = trainer(img, ceof_gt, data["mask"])
            optimizer.zero_grad()


            loss.backward()
            optimizer.step()

            num_iteration += 1
            if num_iteration % 1000 == 0:
                print('epoch {}/{}, iteration: {}, loss: {:.9f}'.format(epoch, args.num_epoch, num_iteration, loss.item()))

        torch.save({
            "epoch": epoch + 1,
            "net": net_model.state_dict(),
            "optimizer": optimizer.state_dict()
        }, "ckpt/%s/%03d.pth" % (args.name, epoch + 1))


    print("training done! ")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", type=str, default="base22", help="name of the experiment")
    parser.add_argument("--ckpt", type=str, default="latest", help="path of the checkpoint")
    parser.add_argument("--gpu_id", type=int, default=7, help="gpu id for cuda")
    parser.add_argument("--batch_size", type=int, default=4, help="num epoch to train")
    parser.add_argument("--num_epoch", type=int, default=5000, help="num epoch to train")
    parser.add_argument("--frequency", type=int, default=100, help="frequency to output result")
    parser.add_argument("--continue_train", type=bool, default=True, help="if continue train")

    parser.add_argument('--T', type=float, default=1000)
    parser.add_argument('--beta_1', type=float, default=1e-4)
    parser.add_argument('--beta_T', type=float, default=0.02)
    parser.add_argument('--grad_clip', type=float, default=1.)
    #parser.add_argument('--multiplier', type=float, default=2.)
    parser.add_argument('--num_res_blocks', type=int, default=2)
    parser.add_argument('--dropout', type=float, default=0.15)
    parser.add_argument('--channel', type=int, default=128)
    parser.add_argument('--channel_mult', default=[1, 2, 3, 4])
    parser.add_argument('--attn', default=[1])
    parser.add_argument('--lr', type=float, default=1e-4)

    args = parser.parse_args()
    train(args)

