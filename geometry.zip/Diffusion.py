
import torch
import torch.nn as nn
import torch.nn.functional as F

import numpy as np

import loss_vgg

import time

from lib.utils.utils import Recon
import os


def extract(v, t, x_shape):
    """
    Extract some coefficients at specified timesteps, then reshape to
    [batch_size, 1, 1, 1, 1, ...] for broadcasting purposes.
    """
    device = t.device
    out = torch.gather(v, index=t, dim=0).float().to(device)
    return out.view([t.shape[0]] + [1] * (len(x_shape) - 1))


class GaussianDiffusionTrainer(nn.Module):
    def __init__(self, model, beta_1, beta_T, T):
        super().__init__()

        self.model = model
        self.T = T

        self.register_buffer(
            'betas', torch.linspace(beta_1, beta_T, T).double())
        alphas = 1. - self.betas
        alphas_bar = torch.cumprod(alphas, dim=0)

        # calculations for diffusion q(x_t | x_{t-1}) and others
        self.register_buffer(
            'sqrt_alphas_bar', torch.sqrt(alphas_bar))
        self.register_buffer(
            'sqrt_one_minus_alphas_bar', torch.sqrt(1. - alphas_bar))

    def forward(self, x_con, x_0, mask):
        """
        Algorithm 1.
        """
        t = torch.randint(self.T, size=(x_0.shape[0], ), device=x_0.device)
        noise = torch.randn_like(x_0)
        x_t = (
            extract(self.sqrt_alphas_bar, t, x_0.shape) * x_0 +
            extract(self.sqrt_one_minus_alphas_bar, t, x_0.shape) * noise)
        x_t = x_t*mask
        result = self.model(x_t, t, x_con)

        #loss = F.l1_loss(result, x_0, reduction='none')
        loss = F.l1_loss(
            torch.masked_select(result, mask),
            torch.masked_select(x_0, mask)
        )
      

        return loss 


class GaussianDiffusionSampler(nn.Module):
    def __init__(self, model, beta_1, beta_T, T):
        super().__init__()

        self.model = model
        self.T = T

        self.register_buffer('betas', torch.linspace(beta_1, beta_T, T).double())
        alphas = 1. - self.betas
        alphas_bar = torch.cumprod(alphas, dim=0)
        alphas_bar_prev = F.pad(alphas_bar, [1, 0], value=1)[:T]

        self.register_buffer('coeff1', torch.sqrt(1. / alphas))
        self.register_buffer('coeff2', self.coeff1 * (1. - alphas) / torch.sqrt(1. - alphas_bar))

        self.register_buffer('posterior_var', self.betas * (1. - alphas_bar_prev) / (1. - alphas_bar))
        # the beginning of the diffusion chain
        self.register_buffer(
            'posterior_log_var_clipped',
            torch.log(
                torch.cat([self.posterior_var[1:2], self.posterior_var[1:]])))
        self.register_buffer(
            'posterior_mean_coef1',
            torch.sqrt(alphas_bar_prev) * self.betas / (1. - alphas_bar))
        self.register_buffer(
            'posterior_mean_coef2',
            torch.sqrt(alphas) * (1. - alphas_bar_prev) / (1. - alphas_bar))

    def predict_xt_prev_mean_from_eps(self, x_t, t, eps):
        assert x_t.shape == eps.shape
        return (
            extract(self.coeff1, t, x_t.shape) * x_t -
            extract(self.coeff2, t, x_t.shape) * eps
        )

    def q_mean_variance(self, x_0, x_t, t):
        """
        Compute the mean and variance of the diffusion posterior
        q(x_{t-1} | x_t, x_0)
        """
        assert x_0.shape == x_t.shape
        posterior_mean = (
            extract(self.posterior_mean_coef1, t, x_t.shape) * x_0 +
            extract(self.posterior_mean_coef2, t, x_t.shape) * x_t
        )
        posterior_log_var_clipped = extract(
            self.posterior_log_var_clipped, t, x_t.shape)
        return posterior_mean, posterior_log_var_clipped

    def p_mean_variance(self, x_t, t, x_con, device):
        # below: only log_variance is used in the KL computations
        var = torch.cat([self.posterior_var[1:2], self.betas[1:]])
        var = extract(var, t, x_t.shape)

        # eps = self.model(x_t, t)
        # xt_prev_mean = self.predict_xt_prev_mean_from_eps(x_t, t, eps=eps)
        xprev = self.model(x_t, t, x_con)
        xt_prev_mean, _ = self.q_mean_variance(xprev, x_t, t)

        return xt_prev_mean, var, xprev

    def forward(self, x_con, mask):
        """
        Algorithm 2.
        """
        #x_t = torch.randn_like(x_con)
        x_t = torch.randn(x_con.shape[0], 32, x_con.shape[2], x_con.shape[3], device=x_con.device)
        x_t = x_t *mask

        e = Recon(device=x_con.device)

        for time_step in reversed(range(self.T)):
            #print(time_step)
            t = x_t.new_ones([x_con.shape[0], ], dtype=torch.long) * time_step
            mean, var,xprev = self.p_mean_variance(x_t=x_t, t=t, x_con=x_con, device=x_con.device)
            # no noise when t == 0
            if time_step > 0:
                noise = torch.randn_like(x_t)
            else:
                noise = 0
            x_t = mean + torch.sqrt(var) * noise
            x_t = x_t * mask
            xprev = xprev*mask

            #print("mean", mean.max(), mean.min())

            #print(time_step)
            if time_step==500:
                test = torch.clip(xprev * mask, -1, 1)
                #test = torch.clip(xprev*mask, -1, 1)
                #v, f = e.decode(test[0])
                #with open(os.path.join("output/", "{}.obj".format(time_step)), "w") as mf:
                    #for i in v:
                       # mf.write("v %f %f %f\n" % (i[0], i[1], i[2]))
                    #for i in f:
                        #mf.write("f %d %d %d\n" % (i[0] + 1, i[1] + 1, i[2] + 1))




            #color = xprev.squeeze(0).permute(1, 2, 0).cpu().detach().numpy()
            #import matplotlib.pyplot as plt

            # Save the image to a file
            #plt.imsave("color/{}_.png".format(time_step), color[:,:,0])

            #import cv2
            #cv2.imwrite("color/{}_.png".format(time_step), np.uint8((color[:, :, 0] + 1) * 127.5))

            assert torch.isnan(x_t).int().sum() == 0, "nan in tensor."
        x_0 = xprev
        return torch.clip(x_0, -1, 1), test


