import torch
import torch.nn as nn
import torch.nn.functional as F


class Swish(nn.Module):
    def forward(self, x):
        return x * torch.sigmoid(x)



class EMA:
    def __init__(self, beta):
        super().__init__()
        self.beta = beta
        self.step = 0

    def update_model_average(self, ma_model, current_model):
        for current_params, ma_params in zip(current_model.parameters(), ma_model.parameters()):
            old_weight, up_weight = ma_params.data, current_params.data
            ma_params.data = self.update_average(old_weight, up_weight)

    def update_average(self, old, new):
        if old is None:
            return new
        return old * self.beta + (1 - self.beta) * new

    def step_ema(self, ema_model, model, step_start_ema=2000):
        if self.step < step_start_ema:
            self.reset_parameters(ema_model, model)
            self.step += 1
            return
        self.update_model_average(ema_model, model)
        self.step += 1

    def reset_parameters(self, ema_model, model):
        ema_model.load_state_dict(model.state_dict())


class SelfAttention(nn.Module):
    def __init__(self, channels, size_h=64, size_w=64):
        super(SelfAttention, self).__init__()
        self.channels = channels
        self.size_h = size_h
        self.size_w = size_w
        self.mha = nn.MultiheadAttention(channels, 4)
        self.ln = nn.LayerNorm([channels])
        self.ff_self = nn.Sequential(
            nn.LayerNorm([channels]),
            nn.Linear(channels, channels),
            nn.GELU(),
            nn.Linear(channels, channels),
        )

    def forward(self, x):
        # x = x.view(-1, self.channels, self.size * self.size).swapaxes(1, 2)
        x = x.view(-1, self.channels, self.size_h * self.size_w).transpose(1, 2)
        print('x.shape:{}'.format(x.shape))
        x_ln = self.ln(x)
        attention_value, _ = self.mha(x_ln, x_ln, x_ln)
        attention_value = attention_value + x
        attention_value = self.ff_self(attention_value) + attention_value
        return attention_value.transpose(2, 1).view(-1, self.channels, self.size_h, self.size_w)


class DoubleConv(nn.Module):
    def __init__(self, in_channels, out_channels, mid_channels=None, residual=False):
        super().__init__()
        self.residual = residual
        if not mid_channels:
            mid_channels = out_channels
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(1, mid_channels),
            nn.GELU(),
            nn.Conv2d(mid_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(1, out_channels),
        )

    def forward(self, x):
        if self.residual:
            return F.gelu(x + self.double_conv(x))
        else:
            return self.double_conv(x)


class Down(nn.Module):
    def __init__(self, in_channels, out_channels, emb_dim=256):
        super().__init__()
        self.maxpool_conv = nn.Sequential(
            nn.MaxPool2d(2),
            DoubleConv(in_channels, in_channels, residual=True),
            DoubleConv(in_channels, out_channels),
        )

        self.emb_layer = nn.Sequential(
            nn.SiLU(),
            nn.Linear(
                emb_dim,
                out_channels
            ),
        )

    def forward(self, x, t):
        x = self.maxpool_conv(x)
        emb = self.emb_layer(t)[:, :, None, None].repeat(1, 1, x.shape[-2], x.shape[-1])
        return x + emb


class Up(nn.Module):
    def __init__(self, in_channels, out_channels, emb_dim=256):
        super().__init__()

        self.up = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=True)
        self.conv = nn.Sequential(
            DoubleConv(in_channels, in_channels, residual=True),
            DoubleConv(in_channels, out_channels, in_channels // 2),
        )

        self.emb_layer = nn.Sequential(
            nn.SiLU(),
            nn.Linear(
                emb_dim,
                out_channels
            ),
        )

    def forward(self, x, skip_x, t):
        x = self.up(x)
        x = torch.cat([skip_x, x], dim=1)
        x = self.conv(x)
        emb = self.emb_layer(t)[:, :, None, None].repeat(1, 1, x.shape[-2], x.shape[-1])
        return x + emb

class Fusion(nn.Module):
    def __init__(self, in_size, out_size):
        super().__init__()
        self.conv1 = nn.Conv2d(in_size, out_size, 4, 2, 1, bias=True)
        self.conv2 = nn.Conv2d(out_size * 2, out_size, 3, 1, 1, bias=True)
        self.relu = nn.ReLU()


    def forward(self, x, y):
        y = self.relu(self.conv1(y))
        x = torch.cat((x, y), dim=1)
        x = self.relu(self.conv2(x))
        return y, x

class UNet(nn.Module):
    #def __init__(self, c_in=3, c_out=3, time_dim=256, device="cuda"):
    def __init__(self, c_in1=32, c_in2=3, c_out=32, time_dim=256): # device=torch.device("cuda:3")
        super(UNet, self).__init__()
        #self.device = device
        self.time_dim = time_dim
        self.inc1 = DoubleConv(c_in1, 64)
        self.inc2 = DoubleConv(c_in2, 64)
        self.down1 = Down(64, 128)
        self.down2 = Down(128, 256)
        self.down3 = Down(256, 512)
        self.down4 = Down(512, 512)
        self.down5 = Down(512, 512)
        self.down6 = Down(512, 512)

        self.fuse1 = Fusion(64, 128)
        self.fuse2 = Fusion(128, 256)
        self.fuse3 = Fusion(256, 512)
        self.fuse4 = Fusion(512, 512)
        self.fuse5 = Fusion(512, 512)

        self.up1 = Up(1024, 512)
        self.up2 = Up(1024, 512)
        self.up3 = Up(1024, 256)
        self.up4 = Up(512, 128)
        self.up5 = Up(256, 64)
        self.up6 = Up(128, 64)
        #self.outc = nn.Conv2d(64, c_out, kernel_size=1,stride=1,padding=1)
        self.outc = nn.Conv2d(64, c_out, kernel_size=1)

    def pos_encoding(self, t, channels, device):
        inv_freq = 1.0 / (10000
            ** (torch.arange(0, channels, 2, device=device).float() / channels)
            #** (torch.arange(0, channels, 2).float() / channels)
        )
        pos_enc_a = torch.sin(t.repeat(1, channels // 2) * inv_freq)
        pos_enc_b = torch.cos(t.repeat(1, channels // 2) * inv_freq)
        pos_enc = torch.cat([pos_enc_a, pos_enc_b], dim=-1)
        return pos_enc

    def forward(self, x, t, y):
        t = t.unsqueeze(-1).type(torch.float)
        t = self.pos_encoding(t, self.time_dim, y.device)

        x1 = self.inc1(x)
        y1 = self.inc2(y)

        # print('x1:{}'.format(x1.shape))
        x2 = self.down1(x1, t)
        # print('x2:{}, y1:{}'.format(x2.shape, y1.shape))
        y2, x21 = self.fuse1(x2, y1)
        x3 = self.down2(x21, t)
        y3, x31 = self.fuse2(x3, y2)
        # print('x3:{}'.format(x3.shape))
        x4 = self.down3(x31, t)
        y4, x41 = self.fuse3(x4, y3)
        # print('x4:{}'.format(x4.shape))
        x5 = self.down4(x41, t)
        y5, x51 = self.fuse4(x5, y4)
        # print('x5:{}'.format(x5.shape))
        x6 = self.down5(x51, t)
        y6, x61 = self.fuse5(x6, y5)
        # print('x6:{}'.format(x6.shape))
        x7 = self.down6(x61, t)
        # print('x7:{}'.format(x6.shape))
        x = self.up1(x7, x61, t)
        x = self.up2(x, x51, t)
        x = self.up3(x, x41, t)
        x = self.up4(x, x31, t)
        x = self.up5(x, x21, t)
        x = self.up6(x, x1, t)

        output = nn.ReLU(inplace=True)(x)

        output = self.outc(output)
        return output

# if __name__ == '__main__':
#     net = UNet(device="cpu")
#     # net = UNet_conditional(num_classes=10, device="cpu")
#     # print(sum([p.numel() for p in net.parameters()]))
#     x = torch.randn(8, 3, 128, 256)
#     t = x.new_tensor([500] * x.shape[0]).long()
#     y = torch.randn(8, 3, 128, 256)
#     # y = x.new_tensor([1] * x.shape[0]).long()
#     print(net(x, t, y).shape)
    # net = SelfAttention(128, 128, 256)
    # x = torch.randn(3, 128, 128, 256)
    # print(net(x).shape)
    # net = Fusion(3, 64)
    # x = torch.randn(8, 64, 64, 128)
    # y = torch.randn(8, 3, 128, 256)
    # print(net(x, y).shape)

