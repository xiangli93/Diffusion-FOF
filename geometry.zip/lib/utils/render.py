from pytorch3d.renderer import (
    BlendParams,
    blending,
    look_at_view_transform,
    FoVOrthographicCameras,
    PointLights,
    RasterizationSettings,
    PointsRasterizationSettings,
    PointsRenderer,
    AlphaCompositor,
    PointsRasterizer,
    MeshRenderer,
    MeshRasterizer,
    SoftPhongShader,
    SoftSilhouetteShader,
    TexturesVertex,
)
from pytorch3d.renderer.mesh import TexturesVertex
from pytorch3d.structures import Meshes, Pointclouds
from lib.utils.mesh_util import get_visibility_face, get_visibility_back
import torch


def query_color(verts, faces, image, image_b, device):
    """query colors from points and image

    Args:
        verts ([B, 3]): [query verts]
        faces ([M, 3]): [query faces]
        image ([B, 3, H, W]): [full image]

    Returns:
        [np.float]: [return colors]
    """

    verts = verts.float().to(device)
    faces = faces.long().to(device)

    (xy, z) = verts.split([2, 1], dim=1)
    visibility_face = get_visibility_face(xy, z, faces[:, [0, 2, 1]])
    visibility_back = get_visibility_back(xy, z, faces[:, [0, 2, 1]])

    uv = xy.unsqueeze(0).unsqueeze(2)  # [B, N, 2]
    uv = uv * torch.tensor([1.0, -1.0]).type_as(uv)

    colors = torch.nn.functional.grid_sample(image, uv, align_corners=True)  # [B, C, N, 1]
    colors = ((colors[0, :, :, 0].permute(1, 0) + 1.0) * 127.5).detach().cpu()

    colors_b = torch.nn.functional.grid_sample(image_b, uv, align_corners=True)  # [B, C, N, 1]
    colors_b = ((colors_b[0, :, :, 0].permute(1, 0) + 1.0) * 127.5).detach().cpu()

    #colors1 = colors.clone()
    #colors1[...,0:1] = colors[...,2:3]
    #colors1[...,2:3] = colors[...,0:1]
    colors_face = colors * visibility_face
    colors_back = colors_b * visibility_back




    #import trimesh
    #mesh = trimesh.Trimesh(verts.detach().cpu(), faces.detach().cpu(), process=False, maintains_order=True)
    #mesh.visual.vertex_colors = colors_new
    #mesh.export( "test.obj")

    return colors_face+ colors_back