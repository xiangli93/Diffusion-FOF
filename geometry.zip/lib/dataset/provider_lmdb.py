import cv2
import lmdb
import numpy as np
from io import BytesIO


class LmdbDataProvider():
    # def __init__(self, path="/mnt/fq_ssd/fq/FOF/lmdb_512") -> None:
    def __init__(self, path="/mnt/data1/LYZ_160/data/data/lmdb_FB_image") -> None:
        self.db = None
        self.path = path

    def open_db(self):
        self.db = lmdb.open(self.path,
                            subdir=True,
                            readonly=True,
                            lock=False,
                            readahead=False,
                            meminit=False)

    def get_data_base(self, name, vid):
        # print("...................   ", name, vid, lid)
        with self.db.begin(write=False) as txn:
            #normal = txn.get(("%s_%03d_normal" % (name, vid)).encode())
            imgF = txn.get(("%s_%03d_imgF" % (name, vid)).encode())
            imgB = txn.get(("%s_%03d_imgB" % (name, vid)).encode())
            mpi = txn.get(("%s_%03d_mpi" % (name, vid)).encode())
        imgF = cv2.imdecode(np.frombuffer(imgF, np.uint8), -1)
        imgB = cv2.imdecode(np.frombuffer(imgB, np.uint8), -1)
        mpi = np.load(BytesIO(mpi))
        #normal = np.load(BytesIO(normal))
        return {"imgF": imgF, "imgB": imgB, "mpi": mpi}
