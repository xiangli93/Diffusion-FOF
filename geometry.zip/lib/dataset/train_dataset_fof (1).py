import torch
import torch.nn as nn
import torch.nn.functional as F
from .ceof_generator import tri_occ
from .provider_lmdb import LmdbDataProvider


class FOFDataset(torch.utils.data.Dataset):
    # def __init__(self, name_list = "/mnt/fq_ssd/fq/FOF/namelist/train.txt") -> None:
    def __init__(self, name_list="/mnt/data/lyz1/data/dataset/data/train.txt") -> None:  # -> None 返回值类型  可有可无
        super().__init__()
        self.data_provider = LmdbDataProvider()
        self.train_mode = True
        with open(name_list, "r") as f:
            self.name_list = f.read().split()

    def open_db(self):
        self.data_provider.open_db()

    def __len__(self):
        if self.train_mode:
            return len(self.name_list) * 256
        else:
            return len(self.name_list)

    def __getitem__(self, index):
        if self.train_mode:
            #print("self.train_mode................")
            pid = index // 256
            vid = index % 128 #256
            lid = int(torch.randint(4, (1,)))
            #print(index, pid, vid, lid)
        else:
            print(".............................................")
            pid = index
            vid = int(torch.randint(256, (1,)))
            lid = int(torch.randint(4, (1,)))
        name = self.name_list[pid]


        data1 = self.data_provider.get_data_base(name, vid, lid)
        img1 = torch.from_numpy(data1["img"].transpose((2, 0, 1)))
        ceof1, mask1 = tri_occ(data1["mpi"]["pos"], data1["mpi"]["ind"], data1["mpi"]["val"], 16)
        ceof1 = torch.from_numpy(ceof1.transpose((2, 0, 1)))
        mask1 = torch.from_numpy(mask1[None])
        normal1 = torch.from_numpy(data1["normal"].transpose((2, 0, 1)))

        data2 = self.data_provider.get_data_base(name, vid+128, lid)
        img2 = torch.from_numpy(data2["img"].transpose((2, 0, 1)))
        ceof2, mask2 = tri_occ(data2["mpi"]["pos"], data2["mpi"]["ind"], data2["mpi"]["val"], 16)
        ceof2 = torch.from_numpy(ceof2.transpose((2, 0, 1)))
        mask2 = torch.from_numpy(mask2[None])
        normal2 = torch.from_numpy(data2["normal"].transpose((2, 0, 1)))

        return {
            "name1": "%s_%03d_%03d" % (name, vid, lid),
            "name2": "%s_%03d_%03d" % (name, vid+128, lid),
            "img1": img1,
            "img2": img2,
            "ceof1": ceof1,
            "ceof2": ceof2,
            "mask1": mask1,
            "mask2": mask2,
            "normal1": normal1,
            "normal2": normal2
        }


def random_init(id):
    torch.utils.data.get_worker_info().dataset.open_db()


def fixed_init(id):
    torch.manual_seed(1000000000 + 7 + id)
    torch.utils.data.get_worker_info().dataset.open_db()


def get_dataloader(fixed=False, batch_size=2):
    return torch.utils.data.DataLoader(FOFDataset(), batch_size=batch_size,
                                       num_workers=8,  # 12
                                       shuffle=not fixed, worker_init_fn=fixed_init if fixed else random_init,
                                       pin_memory=False, persistent_workers=True)
